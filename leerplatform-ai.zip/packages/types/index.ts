export type Role = 'student' | 'teacher' | 'guardian' | 'admin';

export interface Goal {
  id: string;
  domain: 'taal' | 'rekenen' | 'wereldor' | 'other';
  code: string;
  label: string;
  grade: number;
  description?: string;
}

export interface ItemMC {
  id: string;
  goalId: string;
  difficulty: number; // 0..5
  type: 'mc';
  question: string;
  options: string[];
  correctIndex: number;
  hint?: string;
  explanation?: string;
  tags?: string[];
}

export type Item = ItemMC; // uitbreidbaar met 'open'

export interface Session {
  id: string;
  userId: string;
  startedAt: string;
  completedAt?: string;
  items: Item[];
}

export interface Attempt {
  id: string;
  sessionId: string;
  itemId: string;
  response: any;
  isCorrect: boolean;
  timeMs: number;
  hintsUsed: number;
  score: number;
  createdAt: string;
}
