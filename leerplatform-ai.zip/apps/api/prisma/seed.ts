import { PrismaClient } from '@prisma/client';
import * as argon2 from 'argon2';

const prisma = new PrismaClient();

async function main() {
  const password = await argon2.hash('demo1234');
  const teacher = await prisma.user.upsert({
    where: { email: 'juf@example.com' },
    update: {},
    create: { email: 'juf@example.com', name: 'Juf Ann', role: 'teacher', password }
  });
  const student = await prisma.user.upsert({
    where: { email: 'leerling@example.com' },
    update: {},
    create: { email: 'leerling@example.com', name: 'Sam', role: 'student', password }
  });

  const g1 = await prisma.goal.upsert({
    where: { code: 'REK.BRE.GEL' },
    update: {},
    create: { domain: 'rekenen', code: 'REK.BRE.GEL', label: 'Breuken gelijknamig maken', grade: 6 }
  });
  const g2 = await prisma.goal.upsert({
    where: { code: 'TAAL.WW.SPELL' },
    update: {},
    create: { domain: 'taal', code: 'TAAL.WW.SPELL', label: 'Werkwoordspelling tt/vt', grade: 6 }
  });

  await prisma.item.createMany({
    data: [
      {
        id: 'item-breuk-1',
        source: 'ai',
        goalId: g1.id,
        difficulty: 2,
        type: 'mc',
        status: 'live',
        contentJson: {
          question: "Welke vergelijking klopt? Zet **3/4** en **5/8** gelijknamig.",
          options: [
            "3/4 = 6/8 en 5/8 = 10/16",
            "3/4 = 12/16 en 5/8 = 10/16",
            "3/4 = 9/12 en 5/8 = 15/24",
            "3/4 = 8/12 en 5/8 = 12/16"
          ],
          correctIndex: 1,
          hint: "Vermenigvuldig teller en noemer met hetzelfde getal.",
          explanation: "3/4 = 12/16 en 5/8 = 10/16."
        } as any
      },
      {
        id: 'item-ww-1',
        source: 'ai',
        goalId: g2.id,
        difficulty: 2,
        type: 'mc',
        status: 'live',
        contentJson: {
          question: "Kies de juiste vorm: *Hij (word/wordt) later leraar.*",
          options: ["word", "wordt", "wordt't", "werd"],
          correctIndex: 1,
          hint: "Hij = derde persoon enkelvoud.",
          explanation: "Derde persoon enkelvoud: stam + t → wordt."
        } as any
      }
    ]
  });
  console.log({ teacher: teacher.email, student: student.email });
}

main().then(async ()=>{
  await prisma.$disconnect();
}).catch(async (e)=>{
  console.error(e);
  await prisma.$disconnect();
  process.exit(1);
});
