import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaService } from '../services/prisma.service';
import { AuthModule } from './auth/auth.module';
import { GoalsModule } from './goals/goals.module';
import { SessionsModule } from './sessions/sessions.module';
import { AttemptsModule } from './attempts/attempts.module';

@Module({
  imports: [ConfigModule.forRoot({ isGlobal: true }), AuthModule, GoalsModule, SessionsModule, AttemptsModule],
  providers: [PrismaService],
})
export class AppModule {}
