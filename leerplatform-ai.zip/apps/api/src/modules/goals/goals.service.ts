import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../services/prisma.service';

@Injectable()
export class GoalsService {
  constructor(private prisma: PrismaService) {}
  async recommended(userId: string) {
    // naive: return top goals for grade 6
    return this.prisma.goal.findMany({ where: { grade: 6 }, take: 10 });
  }
}
