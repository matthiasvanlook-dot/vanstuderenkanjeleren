import { Controller, Get, Query } from '@nestjs/common';
import { GoalsService } from './goals.service';

@Controller('goals')
export class GoalsController {
  constructor(private goals: GoalsService) {}
  @Get('recommended')
  recommended(@Query('userId') userId: string) {
    return this.goals.recommended(userId);
  }
}
