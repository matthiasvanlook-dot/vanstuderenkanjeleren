import { Body, Controller, Post } from '@nestjs/common';
import { AttemptsService } from './attempts.service';

@Controller('attempts')
export class AttemptsController {
  constructor(private attempts: AttemptsService) {}
  @Post()
  submit(@Body() body: { userId: string; sessionId: string; itemId: string; response: any; timeMs: number; hintsUsed: number; }) {
    return this.attempts.submit(body);
  }
}
