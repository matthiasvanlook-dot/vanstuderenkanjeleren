import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../services/prisma.service';

@Injectable()
export class AttemptsService {
  constructor(private prisma: PrismaService) {}

  async submit(data: { userId: string; sessionId: string; itemId: string; response: any; timeMs: number; hintsUsed: number; }) {
    const item = await this.prisma.item.findUnique({ where: { id: data.itemId } });
    const correctIndex = (item?.contentJson as any)?.correctIndex;
    const isCorrect = data.response?.choiceIndex === correctIndex;
    const score = isCorrect ? 1 : 0;
    const attempt = await this.prisma.attempt.create({
      data: { userId: data.userId, sessionId: data.sessionId, itemId: data.itemId, response: data.response, isCorrect, timeMs: data.timeMs, hintsUsed: data.hintsUsed, score }
    });
    return { attemptId: attempt.id, isCorrect, score };
  }
}
