import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { SessionsService } from './sessions.service';

@Controller('sessions')
export class SessionsController {
  constructor(private sessions: SessionsService) {}
  @Post()
  start(@Body() body: { userId: string; goalIds?: string[]; count?: number; }) {
    return this.sessions.start(body.userId, body.goalIds, body.count ?? 6);
  }
  @Get(':id')
  get() { return { ok: true }; }
}
