import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../services/prisma.service';
import { nanoid } from 'nanoid';

function pick<T>(arr: T[], n: number): T[] {
  const copy = [...arr];
  const out: T[] = [];
  while (out.length < n && copy.length) {
    out.push(copy.splice(Math.floor(Math.random()*copy.length), 1)[0]);
  }
  return out;
}

@Injectable()
export class SessionsService {
  constructor(private prisma: PrismaService) {}

  async start(userId: string, goalIds?: string[], count = 6) {
    const items = await this.prisma.item.findMany({
      where: { status: 'live', ...(goalIds?.length ? { goalId: { in: goalIds } } : {}) },
      take: 50
    });
    const selected = pick(items, Math.min(count, items.length));
    const session = await this.prisma.session.create({ data: { userId } });
    return { sessionId: session.id, items: selected.map(i => ({ id: i.id, type: i.type, content: i.contentJson })) };
  }
}
