'use client';
import { useState } from 'react';

export default function Home() {
  const [email, setEmail] = useState('leerling@example.com');
  const [password, setPassword] = useState('demo1234');
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);

  const login = async () => {
    const res = await fetch(process.env.NEXT_PUBLIC_API_URL + '/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    setToken(data.token);
    setUser(data.user);
  };

  return (
    <div style={{ maxWidth: 480 }}>
      {!token ? (
        <>
          <h1>Inloggen</h1>
          <label>E-mail</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} style={{ width: '100%', padding: 8, marginBottom: 8 }} />
          <label>Wachtwoord</label>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} style={{ width: '100%', padding: 8, marginBottom: 8 }} />
          <button onClick={login} style={{ padding: '8px 12px' }}>Login</button>
          <p style={{ color: '#666' }}>Demo accounts: leerling@example.com / juf@example.com — wachtwoord: demo1234</p>
        </>
      ) : (
        <Dashboard token={token} user={user} />
      )}
    </div>
  );
}

function Dashboard({ token, user }: { token: string; user: any }) {
  const [goals, setGoals] = useState<any[]>([]);
  const [session, setSession] = useState<any | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});

  const loadGoals = async () => {
    const res = await fetch(process.env.NEXT_PUBLIC_API_URL + '/goals/recommended?userId=' + user.id);
    setGoals(await res.json());
  };

  const startSession = async () => {
    const res = await fetch(process.env.NEXT_PUBLIC_API_URL + '/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id, goalIds: goals.map(g=>g.id), count: 5 })
    });
    const data = await res.json();
    setSession(data);
  };

  const submit = async (itemId: string) => {
    const res = await fetch(process.env.NEXT_PUBLIC_API_URL + '/attempts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: user.id,
        sessionId: session.sessionId,
        itemId,
        response: { choiceIndex: answers[itemId] },
        timeMs: 10000,
        hintsUsed: 0
      })
    });
    const data = await res.json();
    alert(data.isCorrect ? 'Correct!' : 'Jammer, probeer opnieuw.');
  };

  return (
    <div>
      <h2>Welkom, {user.name}</h2>
      <button onClick={loadGoals} style={{ padding: '6px 10px', marginRight: 8 }}>Laad aanbevolen doelen</button>
      <button onClick={startSession} style={{ padding: '6px 10px' }}>Start oefensessie</button>
      <h3>Doelen</h3>
      <ul>{goals.map(g => <li key={g.id}>{g.code} — {g.label}</li>)}</ul>
      <h3>Oefensessie</h3>
      {!session ? <p>Nog geen sessie gestart.</p> : (
        <div>
          {session.items.map((it: any) => (
            <div key={it.id} style={{ border: '1px solid #ddd', padding: 12, borderRadius: 8, marginBottom: 12 }}>
              <div dangerouslySetInnerHTML={{ __html: it.content.question.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\*(.*?)\*/g,'<em>$1</em>') }} />
              <ol>
                {it.content.options.map((opt: string, idx: number) => (
                  <li key={idx}>
                    <label>
                      <input type="radio" name={it.id} onChange={()=>setAnswers(a=>({...a,[it.id]: idx}))} />
                      {' '}{opt}
                    </label>
                  </li>
                ))}
              </ol>
              <button onClick={() => submit(it.id)} style={{ padding: '6px 10px' }}>Antwoord indienen</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
